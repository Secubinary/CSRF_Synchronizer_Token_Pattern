package org.csrf.sync.attack.identifiers;

public class Constants {

	public static final String SESSION_ID = "SessionID";

  public static final String CSRF_TOKEN_ENCPT_KEY = "Lisa";
}

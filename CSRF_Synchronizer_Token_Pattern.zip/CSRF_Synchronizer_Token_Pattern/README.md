# CSRF_Synchronizer_Token_Pattern
Synchronization pattern to avoid Cross-Site Request Forgery (CSRF)

[Awesome StackOverflow question and explaination](https://stackoverflow.com/q/16049721/4506140)

![CSRF sync token pattern](https://github.com/JudeNiroshan/CSRF_Synchronizer_Token_Pattern/blob/master/csrf.jpg)

## How to run
This is an eclipse project. Clone this project to your local machine and add to your eclipse IDE. Run this on tomcat servers.
